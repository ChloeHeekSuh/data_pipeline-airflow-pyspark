from pyspark.sql import functions as f
from pipeline_step.pipeline_step import PipelineStep


class PipelineReadTxt(PipelineStep):
    '''this is for model raw to strategy neutral
    '''

    def __init__(self):
        super().__init__()
        print('bbg model raw to strategy neutral')

    def run(self, spark, params, df):
        path = params['input_path']
        return spark.read.csv(path) 