from pyspark.sql import functions as f
from pipeline_step.pipeline_step import PipelineStep


class PipelineTransformTxt(PipelineStep):
    def __init__(self):
        super().__init__()
        print('save data')

    def run(self, spark, params, df):
        output_path = params['output_path']
        df.write.parquet(output_path)
        return df 