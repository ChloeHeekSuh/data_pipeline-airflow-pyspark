from pyspark.sql import functions as f
from pipeline_step.pipeline_step import PipelineStep


class PipelineTransformTxt(PipelineStep):
    def __init__(self):
        super().__init__()
        print('Read File')

    def run(self, spark, params, df):
        path = params['input_path']
        return spark.read.csv(path) 